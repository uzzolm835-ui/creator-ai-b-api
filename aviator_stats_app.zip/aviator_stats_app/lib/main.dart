import 'dart:math';
import 'package:flutter/material.dart';

void main() {
  runApp(const AviatorStatsApp());
}

class Prediction {
  final double value;
  final String level;
  final DateTime time;

  Prediction(this.value, this.level, this.time);
}

class AviatorStatsApp extends StatelessWidget {
  const AviatorStatsApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Aviator Stats',
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.redAccent,
          brightness: Brightness.dark,
        ),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final Random _random = Random();
  double _value = 3.09;
  String _level = 'MEDIUM';
  final List<Prediction> _history = [
    Prediction(3.09, 'MEDIUM', DateTime.now()),
  ];

  void _newPrediction() {
    // Demo simulation only. This does not predict any real game.
    final value = double.parse((1 + _random.nextDouble() * 9).toStringAsFixed(2));
    final level = value < 2
        ? 'LOW'
        : value < 5
            ? 'MEDIUM'
            : 'HIGH';

    setState(() {
      _value = value;
      _level = level;
      _history.insert(0, Prediction(value, level, DateTime.now()));
      if (_history.length > 10) _history.removeLast();
    });
  }

  Color _levelColor(String level) {
    switch (level) {
      case 'LOW':
        return Colors.redAccent;
      case 'MEDIUM':
        return Colors.amber;
      default:
        return Colors.greenAccent;
    }
  }

  @override
  Widget build(BuildContext context) {
    final levelColor = _levelColor(_level);

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          '✈ AVIATOR STATS',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: 0,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.history), label: 'History'),
          NavigationDestination(icon: Icon(Icons.bar_chart), label: 'Stats'),
          NavigationDestination(icon: Icon(Icons.settings_outlined), label: 'Settings'),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Text(
              'AVIATOR DEMO PREDICTION',
              style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            const Text(
              '⚠ Random Demo Simulation • No real game connection',
              style: TextStyle(color: Colors.amber),
            ),
            const SizedBox(height: 20),

            Card(
              elevation: 8,
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  children: [
                    const Text(
                      'PREDICTED MULTIPLIER',
                      style: TextStyle(fontSize: 15, color: Colors.grey),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      '${_value.toStringAsFixed(2)}x',
                      style: const TextStyle(
                        fontSize: 64,
                        fontWeight: FontWeight.w900,
                        color: Colors.redAccent,
                      ),
                    ),
                    const Divider(height: 32),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Text(
                          'LEVEL: ',
                          style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                        ),
                        Icon(Icons.circle, color: levelColor, size: 18),
                        const SizedBox(width: 8),
                        Text(
                          _level,
                          style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            color: levelColor,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 24),
                    SizedBox(
                      width: double.infinity,
                      height: 56,
                      child: FilledButton.icon(
                        onPressed: _newPrediction,
                        icon: const Icon(Icons.refresh),
                        label: const Text(
                          'NEW PREDICTION',
                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 24),
            const Text(
              'RECENT PREDICTIONS',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            ..._history.map(
              (p) => Card(
                child: ListTile(
                  leading: Icon(Icons.circle, color: _levelColor(p.level), size: 18),
                  title: Text(
                    '${p.value.toStringAsFixed(2)}x  •  ${p.level}',
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  subtitle: Text(
                    '${p.time.hour.toString().padLeft(2, '0')}:${p.time.minute.toString().padLeft(2, '0')}',
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
