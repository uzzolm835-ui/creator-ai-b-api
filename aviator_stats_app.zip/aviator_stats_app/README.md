# Aviator Stats Demo App

This is a Flutter demo application.

## Important
- It generates random demo values only.
- It does not predict real Aviator or gambling game results.
- No BOT_TOKEN is included.

## Run
1. Install Flutter.
2. Open this project.
3. Run:
   flutter pub get
   flutter run

## Build APK
flutter build apk --release

The APK will usually be created at:
build/app/outputs/flutter-apk/app-release.apk
